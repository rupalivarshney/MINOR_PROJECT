#################################################################
#   Filename:   StartSnookerGame.py
#   Desc:       Run this file in python terminal to start the game
#
#################################################################


from modules.Initialization import initialization
if __name__ == '__main__':
    initialization()